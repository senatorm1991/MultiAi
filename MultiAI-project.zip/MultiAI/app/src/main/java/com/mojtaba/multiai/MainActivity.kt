package com.mojtaba.multiai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val store = Store(this)
        setContent { MaterialTheme { Surface { App(store) } } }
    }
}

@Composable
fun App(store: Store) {
    var screen by remember { mutableStateOf(0) }
    val providers = remember { mutableStateListOf<Provider>().also { it.addAll(store.load()) } }
    if (screen == 0) {
        ChatScreen(store, providers) { screen = 1 }
    } else {
        SettingsScreen(providers) { store.save(providers); screen = 0 }
    }
}

@Composable
fun ChatScreen(store: Store, providers: List<Provider>, onSettings: () -> Unit) {
    val msgs = remember { mutableStateListOf<Msg>().also { it.addAll(store.loadChat()) } }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size - 1) }

    fun send() {
        val t = input.trim()
        if (t.isEmpty() || busy) return
        input = ""
        msgs.add(Msg("user", t))
        busy = true
        val history = msgs.toList()
        val plist = providers.toList()
        scope.launch {
            val res = withContext(Dispatchers.IO) { runCatching { Router.ask(plist, history) } }
            res.onSuccess { (txt, via) -> msgs.add(Msg("assistant", txt, via)) }
                .onFailure { msgs.add(Msg("error", it.message ?: "خطا")) }
            busy = false
            store.saveChat(msgs.toList())
        }
    }

    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("MultiAI", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            TextButton(onClick = { msgs.clear(); store.saveChat(emptyList()) }) { Text("پاک کردن") }
            TextButton(onClick = onSettings) { Text("تنظیمات") }
        }
        LazyColumn(
            Modifier.weight(1f).padding(horizontal = 8.dp),
            state = listState,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(msgs) { m -> Bubble(m) }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.Bottom) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("پیام...") },
                maxLines = 5,
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { send() }, enabled = !busy) { Text("ارسال") }
        }
    }
}

@Composable
fun Bubble(m: Msg) {
    val isUser = m.role == "user"
    val color = when (m.role) {
        "user" -> MaterialTheme.colorScheme.primaryContainer
        "error" -> MaterialTheme.colorScheme.errorContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    Column(
        Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start,
    ) {
        Surface(color = color, shape = RoundedCornerShape(12.dp)) {
            SelectionContainer { Text(m.text, Modifier.padding(10.dp)) }
        }
        if (m.via.isNotEmpty()) {
            Text(m.via, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
        }
    }
}

@Composable
fun SettingsScreen(providers: SnapshotStateList<Provider>, onBack: () -> Unit) {
    BackHandler { onBack() }
    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("تنظیمات", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            TextButton(onClick = onBack) { Text("ذخیره") }
        }
        LazyColumn(contentPadding = PaddingValues(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Text("ترتیب از بالا به پایین است. وقتی سهمیه یا توکن یک سرویس تمام شود (یا خطا بدهد)، برنامه خودکار سراغ بعدی می‌رود و کل گفتگو را همراه می‌فرستد.")
            }
            itemsIndexed(providers) { i, p ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("${i + 1}. ${p.name}", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                            TextButton(
                                onClick = { val a = providers[i]; providers[i] = providers[i - 1]; providers[i - 1] = a },
                                enabled = i > 0,
                            ) { Text("▲") }
                            TextButton(
                                onClick = { val a = providers[i]; providers[i] = providers[i + 1]; providers[i + 1] = a },
                                enabled = i < providers.lastIndex,
                            ) { Text("▼") }
                            Switch(checked = p.enabled, onCheckedChange = { providers[i] = p.copy(enabled = it) })
                        }
                        OutlinedTextField(
                            value = p.apiKey,
                            onValueChange = { providers[i] = p.copy(apiKey = it.trim()) },
                            label = { Text("API Key") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth(),
                        )
                        OutlinedTextField(
                            value = p.model,
                            onValueChange = { providers[i] = p.copy(model = it.trim()) },
                            label = { Text("Model") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }
        }
    }
}
