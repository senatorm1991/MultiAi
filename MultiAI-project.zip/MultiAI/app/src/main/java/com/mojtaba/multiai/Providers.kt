package com.mojtaba.multiai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Msg(val role: String, val text: String, val via: String = "")

enum class Kind { CLAUDE, GEMINI, OPENAI_COMPAT }

data class Provider(
    val id: String,
    val name: String,
    val kind: Kind,
    val baseUrl: String,
    val model: String,
    val apiKey: String = "",
    val enabled: Boolean = true,
)

class ApiError(val code: Int, msg: String) : Exception("HTTP $code: $msg")

object Defaults {
    fun list() = listOf(
        Provider("claude", "Claude", Kind.CLAUDE, "https://api.anthropic.com/v1/messages", "claude-haiku-5-5"),
        Provider("gemini", "Gemini", Kind.GEMINI, "https://generativelanguage.googleapis.com/v1beta/models", "gemini-2.5-flash"),
        Provider("openai", "OpenAI", Kind.OPENAI_COMPAT, "https://api.openai.com/v1/chat/completions", "gpt-4o-mini"),
        Provider("grok", "Grok", Kind.OPENAI_COMPAT, "https://api.x.ai/v1/chat/completions", "grok-4"),
        Provider("deepseek", "DeepSeek", Kind.OPENAI_COMPAT, "https://api.deepseek.com/chat/completions", "deepseek-chat"),
        Provider("kimi", "Kimi", Kind.OPENAI_COMPAT, "https://api.moonshot.ai/v1/chat/completions", "kimi-k2-0905-preview"),
    )
}

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("multiai", Context.MODE_PRIVATE)

    fun load(): List<Provider> {
        val saved = sp.getString("providers", null) ?: return Defaults.list()
        val base = Defaults.list().associateBy { it.id }
        val out = mutableListOf<Provider>()
        val arr = JSONArray(saved)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val b = base[o.getString("id")] ?: continue
            out += b.copy(
                model = o.optString("model", b.model),
                apiKey = o.optString("key", ""),
                enabled = o.optBoolean("enabled", true),
            )
        }
        Defaults.list().forEach { d -> if (out.none { it.id == d.id }) out += d }
        return out
    }

    fun save(list: List<Provider>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("model", it.model).put("key", it.apiKey).put("enabled", it.enabled))
        }
        sp.edit().putString("providers", arr.toString()).apply()
    }

    fun loadChat(): List<Msg> {
        val s = sp.getString("chat", null) ?: return emptyList()
        val arr = JSONArray(s)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Msg(o.getString("r"), o.getString("t"), o.optString("v", ""))
        }
    }

    fun saveChat(list: List<Msg>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("r", it.role).put("t", it.text).put("v", it.via)) }
        sp.edit().putString("chat", arr.toString()).apply()
    }
}

object Api {
    fun call(p: Provider, history: List<Msg>): String {
        val (url, headers, body) = build(p, history)
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 20000
        c.readTimeout = 120000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw ApiError(code, text.take(200))
        val answer = parse(p.kind, text)
        if (answer.isBlank()) throw ApiError(200, "empty response")
        return answer
    }

    private fun build(p: Provider, h: List<Msg>): Triple<String, Map<String, String>, String> = when (p.kind) {
        Kind.CLAUDE -> {
            val msgs = JSONArray()
            h.forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.text)) }
            val body = JSONObject().put("model", p.model).put("max_tokens", 2048).put("messages", msgs)
            Triple(p.baseUrl, mapOf("x-api-key" to p.apiKey, "anthropic-version" to "2023-06-01"), body.toString())
        }
        Kind.GEMINI -> {
            val contents = JSONArray()
            h.forEach {
                contents.put(
                    JSONObject()
                        .put("role", if (it.role == "assistant") "model" else "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", it.text)))
                )
            }
            Triple(
                "${p.baseUrl}/${p.model}:generateContent",
                mapOf("x-goog-api-key" to p.apiKey),
                JSONObject().put("contents", contents).toString()
            )
        }
        Kind.OPENAI_COMPAT -> {
            val msgs = JSONArray()
            h.forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.text)) }
            val body = JSONObject().put("model", p.model).put("messages", msgs)
            Triple(p.baseUrl, mapOf("Authorization" to "Bearer ${p.apiKey}"), body.toString())
        }
    }

    private fun parse(kind: Kind, text: String): String {
        val o = JSONObject(text)
        return when (kind) {
            Kind.CLAUDE -> {
                val a = o.getJSONArray("content")
                (0 until a.length()).joinToString("") { a.getJSONObject(it).optString("text", "") }
            }
            Kind.GEMINI -> {
                val parts = o.getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts")
                (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text", "") }
            }
            Kind.OPENAI_COMPAT ->
                o.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", "")
        }
    }
}

object Router {
    private val cooldown = mutableMapOf<String, Long>()

    private fun normalize(h: List<Msg>): List<Msg> {
        val out = mutableListOf<Msg>()
        for (m in h) {
            if (m.role != "user" && m.role != "assistant") continue
            if (out.isNotEmpty() && out.last().role == m.role) {
                out[out.lastIndex] = out.last().copy(text = out.last().text + "\n\n" + m.text)
            } else out += m
        }
        var r: List<Msg> = out.takeLast(40)
        while (r.isNotEmpty() && r.first().role != "user") r = r.drop(1)
        return r
    }

    /** Tries providers in order; the full conversation goes to whichever one answers. */
    fun ask(providers: List<Provider>, history: List<Msg>): Pair<String, String> {
        val h = normalize(history)
        val usable = providers.filter { it.enabled && it.apiKey.isNotBlank() }
        if (usable.isEmpty()) throw Exception("هیچ API Key ای در تنظیمات وارد نشده است.")
        val now = System.currentTimeMillis()
        val ready = usable.filter { (cooldown[it.id] ?: 0L) <= now }
        val order = if (ready.isEmpty()) usable else ready
        val errors = mutableListOf<String>()
        for (p in order) {
            try {
                val ans = Api.call(p, h)
                cooldown.remove(p.id)
                val via = if (errors.isEmpty() && p.id == usable.first().id) p.name else p.name + " (جایگزین)"
                return ans to via
            } catch (e: Exception) {
                val ms = when ((e as? ApiError)?.code) {
                    429, 402 -> 3 * 3600_000L
                    401, 403 -> 24 * 3600_000L
                    else -> 120_000L
                }
                cooldown[p.id] = System.currentTimeMillis() + ms
                errors += "${p.name}: ${e.message}"
            }
        }
        throw Exception("همه سرویس‌ها خطا دادند:\n" + errors.joinToString("\n"))
    }
}
